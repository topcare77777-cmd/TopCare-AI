/**
 * @file personality-analytics.js
 * @description Generates deep professional insights, career paths, and action plans based on scores.
 * @module Personality/Analytics
 */

export const PersonalityAnalytics = {
    /**
     * Enriches scoring report with rich enterprise analytics data.
     * @param {Object} scoringReport 
     * @returns {Object}
     */
    generateReport(scoringReport) {
        const meta = scoringReport.primaryMeta || {};

        return {
            ...scoringReport,
            strength: meta.strengths || [],
            weakness: meta.weaknesses || [],
            communication: meta.communicationStyle || "",
            learning: meta.learningStyle || "",
            leadership: meta.leadershipStyle || "",
            compatibility: meta.compatiblePersonality || "",
            stress: meta.stressResponse || "",
            development: meta.developmentAdvice || "",
            career: meta.careerRecommendation || "",
            historicalFigures: meta.historicalFigures || [],
            recommendedJobs: meta.recommendedJobs || [],
            jobsToAvoid: meta.jobsToAvoid || [],
            recommendedStudy: meta.recommendedStudy || ""
        };
    }
};