/**
 * TopCare AI Platform V2.0.0
 * Hero Renderer (BUILD 024 Visual System Activation)
 * Path: assets/js/renderers/hero.renderer.js
 */

import AssetsRegistry from '../config/assets.registry.js';
import ImageHelper from '../helpers/image.helper.js';
import BaseRenderer from '../core/base.renderer.js';
import Logger from '../core/logger.js';

const HeroRenderer = {
    render(data) {
        if (!data) return '';
        Logger.info("[HeroRenderer] HTML generated with full BUILD 024 asset integration");

        const badgeText = BaseRenderer.sanitize(data.badge?.text || 'Next-Gen Intelligence');
        const titleText = BaseRenderer.sanitize(data.title || 'Architecting the Future of Enterprise AI');
        const subtitleText = BaseRenderer.sanitize(data.subtitle || 'Scale operations, automate complex workflows, and empower personal growth with supreme precision.');
        
        // Preload primary hero graphic
        ImageHelper.preloadHeroImage(AssetsRegistry.hero.main);

        const buttonsHtml = (data.buttons || []).map((btn, idx) => `
            <a href="${BaseRenderer.safeURL(btn.link)}" class="btn btn-${BaseRenderer.sanitize(btn.style || (idx === 0 ? 'primary' : 'secondary'))}" aria-label="${BaseRenderer.sanitize(btn.text || '')}">
                <span>${BaseRenderer.sanitize(btn.text || '')}</span>
            </a>
        `).join('');

        const statsHtml = (data.statistics || []).map((stat, idx) => `
            <div class="hero__stat" data-animate="fade-up" style="transition-delay: ${idx * 100}ms;">
                <h2 class="hero__stat-value" data-target="${BaseRenderer.sanitize(stat.value || '0')}">0</h2>
                <span class="hero__stat-label">${BaseRenderer.sanitize(stat.label || '')}</span>
            </div>
        `).join('');

        return `
            <section class="hero" aria-label="Hero Section">
                <div class="hero__aurora-bg" aria-hidden="true" style="background-image: url('${AssetsRegistry.hero.mesh}');">
                    <div class="floating-orb" style="top:15%; left:20%; background-image: url('${AssetsRegistry.hero.glow}');"></div>
                    <div class="floating-orb" style="top:50%; right:15%;"></div>
                </div>
                
                <div class="hero__container">
                    <div class="hero__content" data-animate="fade-right">
                        <div class="hero__badge glass-card">
                            <img src="${AssetsRegistry.icons.brandMark}" alt="" class="hero__brand-icon" loading="lazy" decoding="async" width="18" height="18" />
                            <span class="badge-dot" aria-hidden="true"></span>
                            <span>${badgeText}</span>
                        </div>
                        
                        <h1 class="hero__title">${titleText}</h1>
                        <p class="hero__subtitle">${subtitleText}</p>
                        
                        <div class="hero__buttons">
                            ${buttonsHtml}
                        </div>
                        
                        <div class="hero__stats">
                            ${statsHtml}
                        </div>
                    </div>

                    <div class="hero__preview-wrapper" data-animate="fade-left" data-parallax="0.3">
                        <picture class="hero__main-picture">
                            <source srcset="${AssetsRegistry.hero.main}" type="image/webp">
                            <img src="${AssetsRegistry.hero.main}" alt="TopCare AI Neural Workspace Preview" class="hero__main-image glass-card animated-border" fetchpriority="high" loading="eager" decoding="async" />
                        </picture>
                    </div>
                </div>
            </section>
        `;
    }
};

export default HeroRenderer;