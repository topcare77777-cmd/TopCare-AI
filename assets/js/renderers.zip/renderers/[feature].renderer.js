/**
 * TopCare AI Platform V2.0.0
 * Features Renderer (BUILD 024 SVG Icon Integration)
 * Path: assets/js/renderers/features.renderer.js
 */

import AssetsRegistry from '../config/assets.registry.js';
import BaseRenderer from '../core/base.renderer.js';
import Logger from '../core/logger.js';

const FeaturesRenderer = {
    render(data) {
        if (!data) return '';
        Logger.info("[FeaturesRenderer] Rendered with enterprise SVG assets");

        const tagText = BaseRenderer.sanitize(data.tag || 'Core Features');
        const titleText = BaseRenderer.sanitize(data.title || 'Engineered for High-Performance Workflows');

        const featureIcons = [
            AssetsRegistry.features.aiAssistant,
            AssetsRegistry.features.analytics,
            AssetsRegistry.features.community,
            AssetsRegistry.features.security
        ];

        const cardsHtml = (data.features || []).map((feature, idx) => `
            <div class="features__card glass-card" data-animate="fade-up">
                <div class="features__card-icon">
                    <img src="${featureIcons[idx % featureIcons.length]}" alt="" width="32" height="32" loading="lazy" decoding="async" />
                </div>
                <h3 class="features__card-title">${BaseRenderer.sanitize(feature.title || '')}</h3>
                <p class="features__card-desc">${BaseRenderer.sanitize(feature.description || '')}</p>
            </div>
        `).join('');

        return `
            <section id="features" class="features">
                <div class="features__container">
                    <div class="features__header" data-animate="fade-up">
                        <span class="features__tag">${tagText}</span>
                        <h2 class="features__title">${titleText}</h2>
                    </div>
                    <div class="features__grid">
                        ${cardsHtml}
                    </div>
                </div>
            </section>
        `;
    }
};

export default FeaturesRenderer;