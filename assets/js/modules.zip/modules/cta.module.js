/**
 * TopCare AI Platform V2.0.0
 * CTA Module
 * Path: assets/js/modules/cta.module.js
 */

import BaseModule from '../core/base.module.js';
import CtaService from '../services/cta.service.js';
import CtaRenderer from '../renderers/cta.renderer.js';
import CtaComponent from '../components/cta.component.js';
import MotionEngine from '../core/motion.engine.js';
import GlowEffect from '../core/glow.effect.js';

class CtaModuleClass extends BaseModule {
    constructor() {
        super('Cta', 'cta-wrapper');
        this.service = CtaService;
        this.renderer = CtaRenderer;
        this.component = CtaComponent;
    }

    afterMount() {
        MotionEngine.init();
        GlowEffect.init();
    }
}

export default new CtaModuleClass();