/**
 * TopCare AI Platform V2.0.0
 * Hero Module (RC-4 Enterprise AAA Polish with Smooth CountUp Integration)
 * Path: assets/js/modules/hero.module.js
 */

import BaseModule from '../core/base.module.js';
import HeroService from '../services/hero.service.js';
import HeroRenderer from '../renderers/hero.renderer.js';
import HeroComponent from '../components/hero.component.js';
import MotionEngine from '../core/motion.engine.js';
import GlowEffect from '../core/glow.effect.js';
import Parallax from '../core/parallax.js';
import CountUp from '../core/countUp.js';
import Observer from '../core/observer.js';
import Logger from '../core/logger.js';

class HeroModuleClass extends BaseModule {
    constructor() {
        super('Hero', 'hero-wrapper');
        this.service = HeroService;
        this.renderer = HeroRenderer;
        this.component = HeroComponent;
    }

    afterMount() {
        MotionEngine.init();
        GlowEffect.attach(document.getElementById(this.containerId));
        Parallax.init();

        // Smooth CountUp Animation for Hero Stats
        document.querySelectorAll('.hero__stat-value').forEach(el => {
            Observer.observe(el, (target, obs) => {
                if (!target.classList.contains('counted')) {
                    target.classList.add('counted');
                    const targetVal = target.getAttribute('data-target');
                    if (targetVal) {
                        CountUp.animate(target, targetVal, 2000);
                    }
                }
                obs.unobserve(target);
            });
        });

        Logger.info("[HeroModule] Initialized and post-mount hooks executed successfully.");
    }
}

export default new HeroModuleClass();