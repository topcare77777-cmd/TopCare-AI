/**
 * TopCare AI Platform V2.0.0
 * Base Service
 * Path: assets/js/core/base.service.js
 */

import DataEngine from "../core/data.engine.js";

export default class BaseService {

    constructor(source) {
        this.source = source;
    }

    async all() {
        return await DataEngine.get(this.source);
    }

    async find(id) {
        const data = await this.all();
        if (!Array.isArray(data)) return null;
        return data.find(item => item.id == id);
    }

    async search(keyword) {
        const data = await this.all();
        if (!Array.isArray(data)) return [];
        return data.filter(item =>
            JSON.stringify(item)
            .toLowerCase()
            .includes(keyword.toLowerCase())
        );
    }

    async latest(limit = 5) {
        const data = await this.all();
        if (!Array.isArray(data)) return [];
        return data.slice(0, limit);
    }

}
```[cite: 9]

```javascript
/**
 * TopCare AI Platform V2.0.0
 * Community Repository
 * Path: assets/js/repository/community.repository.js
 */

import DataEngine from "../core/data.engine.js";

const CommunityRepository = {
    async get() {
        try {
            console.log("[CommunityRepository] Loading community data");
            const data = await DataEngine.get("community");
            console.log("[CommunityRepository] Data fetched");
            return data;
        } catch (error) {
            console.error('[CommunityRepository] Error fetching community data:', error);
            return {
                title: "TopCare Community",
                subtitle: "Bergabunglah dengan ribuan pengguna lainnya.",
                items: []
            };
        }
    }
};

export default CommunityRepository;