/**
 * TopCare AI Platform V2.0.0
 * Home Page Controller
 * Path: assets/js/pages/home.page.js
 */

import HeroModule from '../modules/hero.module.js';
import FeaturesModule from '../modules/features.module.js';
import WorkflowModule from '../modules/workflow.module.js';
import ShowcaseModule from '../modules/showcase.module.js';
import TestimonialsModule from '../modules/testimonials.module.js';
import PricingModule from '../modules/pricing.module.js';
import FaqModule from '../modules/faq.module.js';
import FooterModule from '../modules/footer.module.js';
import Logger from '../core/logger.js';

const HomePage = {
    init() { Logger.info("[HomePage] Init"); },
    mount(container) { Logger.info("[HomePage] Mount"); },
    async render(container) {
        Logger.info("[HomePage] Rendering homepage sections...");
        const wrappers = [
            'hero-wrapper', 'trusted-wrapper', 'features-wrapper', 
            'statistics-wrapper', 'workflow-wrapper', 'showcase-wrapper', 
            'testimonials-wrapper', 'pricing-wrapper', 'faq-wrapper', 'cta-wrapper'
        ];
        wrappers.forEach(id => {
            const div = document.createElement('div');
            div.id = id;
            container.appendChild(div);
        });

        if (HeroModule) await HeroModule.mount();
        if (FeaturesModule) await FeaturesModule.mount();
        if (WorkflowModule) await WorkflowModule.mount();
        if (ShowcaseModule) await ShowcaseModule.mount();
        if (TestimonialsModule) await TestimonialsModule.mount();
        if (PricingModule) await PricingModule.mount();
        if (FaqModule) await FaqModule.mount();
        if (FooterModule) await FooterModule.mount();
    },
    destroy() {
        Logger.info("[HomePage] Destroying HomePage and cleaning memory.");
    }
};

export default HomePage;