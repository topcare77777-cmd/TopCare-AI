/**
 * TopCare AI Platform V2.0.0
 * Enterprise Navigation Engine
 * Path: assets/js/core/navigation.engine.js
 */

import RouterEngine from './router.engine.js';
import Logger from './logger.js';

const NavigationEngine = {
    init() {
        Logger.info("[NavigationEngine] Initializing Enterprise Navigation Engine...");
        
        const navLinks = document.querySelectorAll('.nav-links a, .auth-actions a, footer a');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && (href.startsWith('/') || href.startsWith('#'))) {
                let routePath = href;
                if (href.startsWith('#')) {
                    const clean = href.substring(1);
                    routePath = clean === 'hero' ? '/home' : `/${clean}`;
                }

                link.addEventListener('mouseenter', () => {
                    RouterEngine.prefetch(routePath);
                });
            }
        });

        Logger.info("[NavigationEngine] Navigation Engine active.");
    },

    updateActiveNav(path) {
        const navLinks = document.querySelectorAll('.nav-links a');
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === path || (path === '/home' && (href === '/hero' || href === '/'))) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }
};

export default NavigationEngine;