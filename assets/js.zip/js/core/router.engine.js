/**
 * TopCare AI Platform V2.0.0
 * Enterprise Router Engine (BUILD 028.6 SPA Interception)
 * Path: assets/js/core/router.engine.js
 */

import PageLoader from './page.loader.js';
import HistoryEngine from './history.engine.js';
import PageRegistry from '../pages/page.registry.js';
import Logger from './logger.js';

const RouterEngine = {
    init() {
        Logger.info("[RouterEngine] Initializing Enterprise Router Engine...");
        
        HistoryEngine.init((path) => {
            this.handleRoute(path, false);
        });

        // Intercept all clicks globally to prevent any live server 404 HTTP requests
        document.addEventListener('click', (e) => {
            const anchor = e.target.closest('a');
            if (!anchor) return;

            const href = anchor.getAttribute('href');
            if (!href) return;

            // Check if internal route
            if (href.startsWith('/') || href.startsWith('#')) {
                e.preventDefault();
                let routePath = href;
                if (href.startsWith('#')) {
                    const clean = href.substring(1);
                    routePath = clean === 'hero' ? '/home' : `/${clean}`;
                }
                this.navigate(routePath, true);
            }
        });

        const currentPath = window.location.pathname === '' || window.location.pathname === '/' ? '/home' : window.location.pathname;
        this.navigate(currentPath, false);
        Logger.info("[RouterEngine] Router Engine active with full request interception.");
    },

    navigate(path, push = true) {
        const cleanPath = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
        if (push) {
            HistoryEngine.push(cleanPath);
        }
        this.handleRoute(cleanPath, true);
    },

    async handleRoute(path, updateScroll = true) {
        const cleanPath = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
        const pageKey = PageRegistry.resolve(cleanPath);
        
        Logger.info(`[RouterEngine] SPA Intercepted route: ${cleanPath} -> Page Key: ${pageKey}`);
        await PageLoader.load(pageKey);

        if (updateScroll) {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    },

    prefetch(path) {
        const cleanPath = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
        const pageKey = PageRegistry.resolve(cleanPath);
        if (pageKey) {
            if ('requestIdleCallback' in window) {
                requestIdleCallback(() => {
                    PageLoader.prefetch(pageKey);
                });
            } else {
                setTimeout(() => {
                    PageLoader.prefetch(pageKey);
                }, 200);
            }
        }
    }
};

export default RouterEngine;